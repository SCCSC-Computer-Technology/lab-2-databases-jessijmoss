﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JMoss_CPT206_A80H_Lab2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void cityBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cityBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.cityDBDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cityDBDataSet.City' table. You can move, or remove it, as needed.
            this.cityTableAdapter.Fill(this.cityDBDataSet.City);

        }

        private void btnSortLowPop_Click(object sender, EventArgs e)
        {
            //sort population low to high via Query created
            this.cityTableAdapter.PopulationAscending(this.cityDBDataSet.City);
        }

        private void btnSortHighPop_Click(object sender, EventArgs e)
        {
            //sort population high to low via Query created
            this.cityTableAdapter.PopulationDescending(this.cityDBDataSet.City);
        }

        private void btnSortName_Click(object sender, EventArgs e)
        {
            //sort city name A to Z via Query created
            this.cityTableAdapter.FillByCityName(this.cityDBDataSet.City);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //open AddForm as dialog to add new city to database
            AddForm addForm = new AddForm();

            //create fail /success check
            if (addForm.ShowDialog() == DialogResult.OK)
            {
                //add the new city to the database
                this.cityTableAdapter.AddQuery(addForm.GetCity(), addForm.GetState(), Convert.ToInt32(addForm.GetPopulation()));
                //refresh the datagridview
                this.cityTableAdapter.Fill(this.cityDBDataSet.City);

                //refresh datagrid from any changes
                this.cityDataGridView.Refresh();

                //show confirmation message
                MessageBox.Show("New city added successfully!", "Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                //failure message
                MessageBox.Show("City addition cancelled or failed.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //make sure user has selected a city to delete
            if (cityDataGridView.CurrentRow == null)
            {
                //makes sure user has selected a row
                MessageBox.Show("Please select a city to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else
            {
                //ensure user wants to delete selected city
                DialogResult result = MessageBox.Show("Are you sure you want to delete the selected city?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (cityDataGridView.CurrentRow != null)
                {
                   
                    //get the selected row from the datagridview
                    int selectedRowIndex = cityDataGridView.CurrentCell.RowIndex;

                    // removes row not via the query but directly from the dataset
                    // I couldn't get my delete query to work properly
                    this.cityDataGridView.Rows.RemoveAt(selectedRowIndex);

                    //update the database with changes made to the dataset
                    this.cityDataGridView.Refresh();

                    //show confirmation message
                    MessageBox.Show("City deleted successfully!", "Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    

                }
            }
                
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                //get the selected row from datagridview
                int selectedRowIndex = cityDataGridView.CurrentCell.RowIndex;

                //save changes made to table
                this.cityDataGridView.EndEdit();

                //ends edit to the binding source
                this.cityBindingSource.EndEdit();

                //Updates changes to the database
                this.cityTableAdapter.Update(this.cityDBDataSet.City);

                //display message showing successful update
                MessageBox.Show("City information updated.");
            }
            catch
            {
                MessageBox.Show("Update failed.");
            }
            

          
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnTotalPop_Click(object sender, EventArgs e)
        {
            // convert the object return via the query to a var
            var totalPop = this.cityTableAdapter.populationTotal();

            if (totalPop != null)
            {
                //refresh datagrid from any changes
                this.cityDataGridView.Refresh();
                MessageBox.Show("Total Population of all cities: " + totalPop);
            }
            else
            {
                MessageBox.Show("Error Calculating Population of all cities.");
            }
        }

        private void btnAvgPop_Click(object sender, EventArgs e)
        {
            //covert the object returned via the query to a var
            var avgPop = this.cityTableAdapter.avgPopulation();

            if (avgPop != null)
            {
                //refresh datagrid from any changes
                this.cityDataGridView.Refresh();
                MessageBox.Show("Average Population of all cities: " + avgPop);
            }
            else
            {
                MessageBox.Show("Error Calculating Average Population of all Cities.");
            }
        }
    }
}
