﻿namespace JMoss_CPT206_A80H_Lab2
{


    partial class CityDBDataSet
    {
    }
}

