﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JMoss_CPT206_A80H_Lab2
{
    public partial class AddForm : Form
    {
        public AddForm()
        {
            InitializeComponent();
        }

        public string GetCity()
        {
            //return city name from textbox to send to main form
            return txtCityName.Text;
        }

        public string GetState()
        {
            //return state name from textbox to send to main form
            return txtStateName.Text;
        }

        public string GetPopulation()
        {
            //return population from textbox to send to main form
            return txtPopulation.Text;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            //clears form textboxes
            txtCityName.Clear();
            txtPopulation.Clear();
            txtStateName.Clear();
        }

        private void btnSaveExit_Click(object sender, EventArgs e)
        {
            //set dialog result to OK and close form to send data back to main form
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
